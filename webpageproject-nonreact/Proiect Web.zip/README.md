Acest "website" este un demo la o firma

Pagini incluse:
- `index.html`: Pagina de home a demo-ului
- `services.html`: Afiseaza o lista de produse, pe scurt , simplu pe ce s-a studiat pe parcursul laboratoarelor.
- `about.html`: informatii companie
- `contact.html`: detalii contact

JavaScript:
- Dynamically generates a table on the services page.
- Calculates values dynamically (e.g., prices).

Bonus:
S-a folosit Bootstrap pentru stilizarea CSS-ului pe fiecare pagina de format HTML ceea ce e ok, am inteles cate ceva.

